package com.expenselogics.repository;

import com.expenselogics.model.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query; // <-- CRUCIAL: Must be imported to use @Query
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    
    // Default Spring Data JPA method to find all expenses for a specific user ID
    List<Expense> findByUserId(Long userId);

    // Custom method to Group expenses by category and sum the amounts for a user
    // This resolves the error in FinancialAnalysisService.java (Line 66)
    @Query("SELECT e.category, SUM(e.amount) FROM Expense e WHERE e.user.id = :userId GROUP BY e.category")
    List<Object[]> getCategoryTotalsByUserId(Long userId);
}

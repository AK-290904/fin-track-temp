package com.expenselogics.service;

import com.expenselogics.model.Debt;
import com.expenselogics.model.Expense;
import com.expenselogics.model.User;
import com.expenselogics.repository.DebtRepository;
import com.expenselogics.repository.ExpenseRepository;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class FinancialAnalysisService {

    private final ExpenseRepository expenseRepository;
    private final DebtRepository debtRepository;

    // Dependency Injection: Spring automatically provides the repositories
    public FinancialAnalysisService(ExpenseRepository expenseRepository, DebtRepository debtRepository) {
        this.expenseRepository = expenseRepository;
        this.debtRepository = debtRepository;
    }

    // --- Helper DTOs to structure the complex analysis output ---
    @Data
    public static class AnalysisResult {
        private Map<String, Object> budgetAnalysis;
        private Map<String, Object> savingsStrategy;
        private Map<String, Object> debtReduction;
    }

    // --- Core Logic (Replaces LLM Agents) ---

    public AnalysisResult performFullAnalysis(User user) {
        // Fetch data
        // WARNING: We are fetching expenses/debts for user ID 1L due to simplified user management in the controller
        List<Expense> expenses = expenseRepository.findByUserId(1L); 
        List<Debt> debts = debtRepository.findByUserId(1L);
        
        AnalysisResult result = new AnalysisResult();

        // 1. Budget Analysis
        result.setBudgetAnalysis(runBudgetAnalysis(user, expenses));

        // 2. Savings Strategy
        // Pass the total expenses calculated in the budget analysis to the savings module
        result.setSavingsStrategy(runSavingsStrategy(user, (Double) result.getBudgetAnalysis().get("totalExpenses")));

        // 3. Debt Reduction
        result.setDebtReduction(runDebtReduction(user, debts));

        return result;
    }

    // --- Module 1: Budget Analysis (Heuristic/Rules-Based Logic) ---
    private Map<String, Object> runBudgetAnalysis(User user, List<Expense> expenses) {
        Map<String, Object> result = new HashMap<>();
        
        // Group expenses by category and sum the amounts (This relies on the custom query in the repository)
        List<Object[]> categorySums = expenseRepository.getCategoryTotalsByUserId(1L);
        Map<String, Double> categoryTotals = categorySums.stream()
                .collect(Collectors.toMap(
                    obj -> (String) obj[0],
                    obj -> (Double) obj[1]
                ));

        double totalExpenses = categoryTotals.values().stream().mapToDouble(Double::doubleValue).sum();
        double monthlyIncome = 5000.0; // Hardcoded default, since we don't have user input for it in the DB yet
        double surplusDeficit = monthlyIncome - totalExpenses;

        result.put("monthlyIncome", monthlyIncome);
        result.put("totalExpenses", totalExpenses);
        result.put("surplusDeficit", surplusDeficit);
        
        // Map spending categories to the required JSON structure
        List<Map<String, Object>> spendingCategories = categoryTotals.entrySet().stream()
            .map(entry -> {
                Map<String, Object> cat = new HashMap<>();
                cat.put("category", entry.getKey());
                cat.put("amount", entry.getValue());
                cat.put("percentage", totalExpenses > 0 ? (entry.getValue() / totalExpenses * 100) : 0.0);
                return cat;
            })
            .collect(Collectors.toList());
        result.put("spendingCategories", spendingCategories);

        // Simple Heuristic Recommendation: Identify the largest discretionary spending area.
        String recCategory = categoryTotals.keySet().stream()
            .filter(c -> !List.of("Housing", "Utilities", "Healthcare").contains(c))
            .max(Comparator.comparingDouble(categoryTotals::get))
            .orElse("Other");
        
        List<Map<String, Object>> recommendations = new ArrayList<>();
        Map<String, Object> rec = new HashMap<>();
        rec.put("category", recCategory);
        rec.put("recommendation", String.format("You are spending a large amount on %s. Aim to cut 10%% of this spending.", recCategory));
        rec.put("potentialSavings", categoryTotals.getOrDefault(recCategory, 0.0) * 0.10);
        recommendations.add(rec);
        
        result.put("recommendations", recommendations);
        
        return result;
    }

    // --- Module 2: Savings Strategy (Heuristic/Rules-Based Logic) ---
    private Map<String, Object> runSavingsStrategy(User user, double totalExpenses) {
        Map<String, Object> result = new HashMap<>();
        double monthlyIncome = 5000.0;

        // Emergency Fund: 4-6 months of expenses, adjusted by dependants
        double months = user.getDependants() > 0 ? 6.0 : 4.0;
        double recommendedEF = totalExpenses * months;
        
        Map<String, Object> emergencyFund = new HashMap<>();
        emergencyFund.put("recommendedAmount", recommendedEF);
        emergencyFund.put("currentAmount", 0.0); 
        emergencyFund.put("currentStatus", recommendedEF > 0 ? "Needs funding" : "Goal met");
        result.put("emergencyFund", emergencyFund);

        // Savings Allocation: Based on 50/30/20 rule (15% for retirement is aggressive/good)
        List<Map<String, Object>> savingsRecommendations = new ArrayList<>();
        
        Map<String, Object> retirement = new HashMap<>();
        retirement.put("category", "Retirement (15%)");
        retirement.put("amount", monthlyIncome * 0.15);
        retirement.put("rationale", "Prioritize long-term tax-advantaged savings (e.g., 401k/IRA).");
        savingsRecommendations.add(retirement);
        
        Map<String, Object> fundBuild = new HashMap<>();
        fundBuild.put("category", "Emergency Fund Build");
        fundBuild.put("amount", monthlyIncome * 0.05); // Allocate 5% of income towards EF
        fundBuild.put("rationale", "Allocate this amount monthly to reach the emergency fund target.");
        savingsRecommendations.add(fundBuild);

        result.put("recommendations", savingsRecommendations);
        
        List<Map<String, Object>> automationTechniques = List.of(
            Map.of("name", "Pay-Yourself-First", "description", "Automate transfers on payday to your savings/retirement accounts first."),
            Map.of("name", "Round-Up Savings", "description", "Use bank features to round up purchases to the nearest dollar and save the difference.")
        );
        result.put("automationTechniques", automationTechniques);

        return result;
    }

    // --- Module 3: Debt Reduction (Heuristic/Rules-Based Logic) ---
    private Map<String, Object> runDebtReduction(User user, List<Debt> debts) {
        Map<String, Object> result = new HashMap<>();
        
        double totalDebt = debts.stream().mapToDouble(Debt::getCurrentBalance).sum();
        result.put("totalDebt", totalDebt);
        result.put("debts", debts);

        // Assume an extra budget of $500 for debt payoff (can be adjusted by user)
        final double EXTRA_PAYMENT = 500.0;
        
        // 1. Avalanche: Highest Interest First (Most mathematically optimal)
        List<Debt> sortedAvalanche = debts.stream()
            .sorted(Comparator.comparingDouble(Debt::getInterestRate).reversed())
            .toList();
        
        Map<String, Object> avalanchePlan = calculatePayoff(sortedAvalanche, EXTRA_PAYMENT);
        
        // 2. Snowball: Smallest Balance First (Most motivational)
        List<Debt> sortedSnowball = debts.stream()
            .sorted(Comparator.comparingDouble(Debt::getCurrentBalance))
            .toList();
            
        Map<String, Object> snowballPlan = calculatePayoff(sortedSnowball, EXTRA_PAYMENT);

        Map<String, Object> payoffPlans = new HashMap<>();
        payoffPlans.put("avalanche", avalanchePlan);
        payoffPlans.put("snowball", snowballPlan);
        result.put("payoffPlans", payoffPlans);
        
        // Debt Recommendations
        List<Map<String, Object>> recommendations = List.of(
            Map.of("title", "Refinance High Interest", "description", "Look into consolidating or refinancing your highest-rate debt to reduce interest.", "impact", "Save hundreds or thousands in interest."),
            Map.of("title", "Attack Smallest Debt (Snowball)", "description", "For psychological wins, prioritize paying off the smallest debt first, then roll that payment into the next smallest.", "impact", "Increased motivation and quick wins.")
        );
        result.put("recommendations", recommendations);

        return result;
    }

    // Simplified Payoff Calculation (Used for both Avalanche and Snowball simulation)
    private Map<String, Object> calculatePayoff(List<Debt> debts, double extraPayment) {
        if (debts.isEmpty()) {
             return Map.of("totalInterest", 0.0, "monthsToPayoff", 0, "monthlyPayment", 0.0);
        }
        
        double principal = debts.stream().mapToDouble(Debt::getCurrentBalance).sum();
        double minPayments = debts.stream().mapToDouble(Debt::getMinPayment).sum();
        double totalPayment = minPayments + extraPayment;
        
        double avgInterestRate = debts.stream().mapToDouble(Debt::getInterestRate).average().orElse(5.0) / 100.0;
        double monthlyInterestRate = avgInterestRate / 12;

        int monthsToPayoff = 0;
        double currentBalance = principal;
        double totalInterestPaid = 0.0;
        
        if (totalPayment > 0 && currentBalance > 0) {
            // Simplified loop simulation (not perfect amortization, but good for relative comparison)
            for (int i = 0; i < 600 && currentBalance > 0; i++) { // Max 50 years to prevent infinite loops
                double interestDue = currentBalance * monthlyInterestRate;
                double principalPaid = totalPayment - interestDue;
                
                if (principalPaid <= 0) { 
                    // If payment barely covers interest, it will take a long time. Break out with a large number.
                    monthsToPayoff = 999;
                    totalInterestPaid = principal * 0.5; // Large arbitrary interest
                    break;
                }
                
                currentBalance -= principalPaid;
                totalInterestPaid += interestDue;
                monthsToPayoff++;
            }
        }
        
        return Map.of(
            "totalInterest", totalInterestPaid,
            "monthsToPayoff", monthsToPayoff,
            "monthlyPayment", totalPayment
        );
    }
}

package com.expenselogics.repository;

import com.expenselogics.model.Debt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

// JpaRepository provides CRUD (Create, Read, Update, Delete) operations out of the box.
@Repository
public interface DebtRepository extends JpaRepository<Debt, Long> {
    // Custom method to find all debts for a specific user ID
    List<Debt> findByUserId(Long userId);
}

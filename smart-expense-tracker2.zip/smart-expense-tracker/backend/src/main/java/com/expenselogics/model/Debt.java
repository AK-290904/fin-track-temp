package com.expenselogics.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType; // <-- CORRECTED IMPORT
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.Data;

// Represents a user's debt item
@Entity
@Table(name = "debts")
@Data
public class Debt {
    @Id
    // CORRECTED USAGE: We must specify the class name 'GenerationType'
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private double currentBalance;
    private double interestRate; // Annual interest rate (e.g., 5.0 for 5%)
    private double minPayment;
    
    @ManyToOne // Defines the many-to-one relationship: many debts belong to one user
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

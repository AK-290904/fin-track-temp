package com.expenselogics.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.Data;
import java.time.LocalDate;

// Represents a single expense transaction
@Entity
@Table(name = "expenses")
@Data
public class Expense {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDate date;
    private String description;
    private String category; // e.g., Food, Travel, Housing
    private double amount;
    
    @ManyToOne // Defines the many-to-one relationship: many expenses belong to one user
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

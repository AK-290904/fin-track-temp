package com.expenselogics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

// @SpringBootApplication is the main annotation that starts Spring Boot
@SpringBootApplication
// Tells Spring where to find your repository interfaces (ExpenseRepository, DebtRepository)
@EnableJpaRepositories(basePackages = "com.expenselogics.repository") 
public class SmartExpenseTrackerApplication {

    public static void main(String[] args) {
        // This is the entry point that launches the entire Spring application
        SpringApplication.run(SmartExpenseTrackerApplication.class, args);
    }
}

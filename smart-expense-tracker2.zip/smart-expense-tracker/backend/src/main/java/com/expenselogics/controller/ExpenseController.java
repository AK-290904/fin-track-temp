package com.expenselogics.controller;

import com.expenselogics.model.Debt;
import com.expenselogics.model.Expense;
import com.expenselogics.model.User;
import com.expenselogics.repository.DebtRepository;
import com.expenselogics.repository.ExpenseRepository;
import com.expenselogics.service.FinancialAnalysisService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

// Set up CORS to allow the HTML frontend to communicate (running on a different port)
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RestController
@RequestMapping("/api")
public class ExpenseController {

    // Simulating user authentication (in a real app, this would use Spring Security)
    // We hardcode User ID 1 for all operations for simplification.
    private static final Long SIMULATED_USER_ID = 1L;
    private final ExpenseRepository expenseRepository;
    private final DebtRepository debtRepository;
    private final FinancialAnalysisService analysisService;

    // Dependency Injection: Spring automatically provides these components
    public ExpenseController(ExpenseRepository expenseRepository, DebtRepository debtRepository, FinancialAnalysisService analysisService) {
        this.expenseRepository = expenseRepository;
        this.debtRepository = debtRepository;
        this.analysisService = analysisService;
        
        // Ensure a user exists for testing (simplification)
        ensureTestUserExists();
    }

    // Since we don't have a full UserRepository, we simulate a test user entity for foreign keys
    private User getSimulatedUser() {
        User user = new User();
        user.setId(SIMULATED_USER_ID);
        user.setUsername("akshita");
        user.setDependants(0); // Set a default; can be adjusted later
        return user;
    }
    
    // Temporary helper to ensure the user ID 1 exists for the foreign keys to work
    private void ensureTestUserExists() {
        // In a full application, this user would be created via registration. 
        // Here, we just assume ID 1L exists in the database for foreign key constraints to work correctly.
        System.out.println("INFO: Assuming User with ID 1L (akshita) exists for foreign key constraints.");
    }
    
    // --- Expense Endpoints ---

    // POST /api/expenses - Creates a new expense
    @PostMapping("/expenses")
    public Expense createExpense(@RequestBody Expense expense) {
        // Automatically set the simulated user to fulfill foreign key requirement
        expense.setUser(getSimulatedUser()); 
        if (expense.getDate() == null) {
            expense.setDate(LocalDate.now());
        }
        return expenseRepository.save(expense);
    }

    // GET /api/expenses - Retrieves all expenses for the user
    @GetMapping("/expenses")
    public List<Expense> getAllExpenses() {
        return expenseRepository.findByUserId(SIMULATED_USER_ID);
    }
    
    // DELETE /api/expenses/{id} - Deletes an expense
    @DeleteMapping("/expenses/{id}")
    public void deleteExpense(@PathVariable Long id) {
        Optional<Expense> expense = expenseRepository.findById(id);
        if (expense.isPresent() && expense.get().getUser().getId().equals(SIMULATED_USER_ID)) {
             expenseRepository.deleteById(id);
        }
    }
    
    // --- Debt Endpoints ---
    
    // POST /api/debts - Creates a new debt
    @PostMapping("/debts")
    public Debt createDebt(@RequestBody Debt debt) {
        debt.setUser(getSimulatedUser());
        return debtRepository.save(debt);
    }

    // GET /api/debts - Retrieves all debts for the user
    @GetMapping("/debts")
    public List<Debt> getAllDebts() {
        return debtRepository.findByUserId(SIMULATED_USER_ID);
    }
    
    // DELETE /api/debts/{id} - Deletes a debt
    @DeleteMapping("/debts/{id}")
    public void deleteDebt(@PathVariable Long id) {
        Optional<Debt> debt = debtRepository.findById(id);
        if (debt.isPresent() && debt.get().getUser().getId().equals(SIMULATED_USER_ID)) {
             debtRepository.deleteById(id);
        }
    }
    
    // --- Analysis Endpoint (Core Financial Coach Functionality) ---

    // GET /api/analyze - Runs the full three-part analysis
    @GetMapping("/analyze")
    public FinancialAnalysisService.AnalysisResult runAnalysis() {
        User user = getSimulatedUser();
        // The service performs the heavy analysis using data from the repositories
        return analysisService.performFullAnalysis(user);
    }
}
